package com.zybooks.inventory;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SearchView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class inventory extends AppCompatActivity {

    private InventoryDatabase dbHelper;
    private GridView gridView;
    private SearchView searchView;
    private Button searchButton, printButton;
    private FloatingActionButton floatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new InventoryDatabase(this);
        gridView = findViewById(R.id.gridView);
        searchView = findViewById(R.id.searchView);
        searchButton = findViewById(R.id.searchButton);
        printButton = findViewById(R.id.printButton);
        floatingActionButton = findViewById(R.id.floatingActionButton2);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = searchView.getQuery().toString();
                searchItems(query);
            }
        });

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle adding new item
                addItem("New Item", 5, 19.99);
            }
        });

        printButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle print action
                Toast.makeText(inventory.this, "Print action clicked", Toast.LENGTH_SHORT).show();
            }
        });

        retrieveItems();
    }

    private void addItem(String itemName, int quantity, double price) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.COLUMN_ITEM_NAME, itemName);
        values.put(InventoryDatabase.COLUMN_QUANTITY, quantity);
        values.put(InventoryDatabase.COLUMN_PRICE, price);
        long newRowId = db.insert(InventoryDatabase.TABLE_NAME, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Success!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }

    private void retrieveItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                InventoryDatabase.COLUMN_ID,
                InventoryDatabase.COLUMN_ITEM_NAME,
                InventoryDatabase.COLUMN_QUANTITY,
                InventoryDatabase.COLUMN_PRICE
        };
        Cursor cursor = db.query(
                InventoryDatabase.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long itemId = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ITEM_NAME));
            int itemQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_QUANTITY));
            double itemPrice = cursor.getDouble(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_PRICE));
            String itemInfo = "ID: " + itemId + ", Name: " + itemName + ", Quantity: " + itemQuantity + ", Price: " + itemPrice;
            Toast.makeText(this, itemInfo, Toast.LENGTH_LONG).show();
        }
        cursor.close();
    }

    private void searchItems(String query) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                InventoryDatabase.COLUMN_ID,
                InventoryDatabase.COLUMN_ITEM_NAME,
                InventoryDatabase.COLUMN_QUANTITY,
                InventoryDatabase.COLUMN_PRICE
        };
        String selection = InventoryDatabase.COLUMN_ITEM_NAME + " LIKE ?";
        String[] selectionArgs = { "%" + query + "%" };
        Cursor cursor = db.query(
                InventoryDatabase.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long itemId = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ITEM_NAME));
            int itemQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_QUANTITY));
            double itemPrice = cursor.getDouble(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_PRICE));
            String itemInfo = "ID: " + itemId + ", Name: " + itemName + ", Quantity: " + itemQuantity + ", Price: " + itemPrice;
            Toast.makeText(this, itemInfo, Toast.LENGTH_LONG).show();
        }
        cursor.close();
    }
}
