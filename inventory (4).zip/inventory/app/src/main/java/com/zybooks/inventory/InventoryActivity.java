package com.zybooks.inventory;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SearchView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryActivity extends AppCompatActivity {

    private InventoryDatabase dbHelper;
    private GridView gridView;
    private SearchView searchView;
    private Button searchButton, printButton;
    private FloatingActionButton floatingActionButton;

    private static final String TAG = "InventoryActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new InventoryDatabase(this);
        gridView = findViewById(R.id.gridView);
        searchView = findViewById(R.id.searchView);
        searchButton = findViewById(R.id.searchButton);
        printButton = findViewById(R.id.printButton);
        floatingActionButton = findViewById(R.id.floatingActionButton2);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = searchView.getQuery().toString();
                searchItems(query);
            }
        });

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "FloatingActionButton clicked");
                showAddItemDialog();
            }
        });

        printButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(InventoryActivity.this, "Print action clicked", Toast.LENGTH_SHORT).show();
            }
        });

        retrieveItems();
    }

    private void showAddItemDialog() {
        Log.d(TAG, "showAddItemDialog() called");
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        final EditText itemNameEditText = dialogView.findViewById(R.id.item_name_edittext);
        final EditText itemQuantityEditText = dialogView.findViewById(R.id.item_quantity_edittext);
        final EditText itemPriceEditText = dialogView.findViewById(R.id.item_price_edittext);
        Button saveButton = dialogView.findViewById(R.id.save_button);

        AlertDialog dialog = builder.create();
        dialog.show();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Save button clicked in dialog");
                String itemName = itemNameEditText.getText().toString().trim();
                String itemQuantityString = itemQuantityEditText.getText().toString().trim();
                String itemPriceString = itemPriceEditText.getText().toString().trim();

                if (itemName.isEmpty() || itemQuantityString.isEmpty() || itemPriceString.isEmpty()) {
                    Toast.makeText(InventoryActivity.this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                } else {
                    int itemQuantity = Integer.parseInt(itemQuantityString);
                    double itemPrice = Double.parseDouble(itemPriceString);
                    addItem(itemName, itemQuantity, itemPrice);
                    dialog.dismiss();
                }
            }
        });
    }

    private void addItem(String itemName, int quantity, double price) {
        Log.d(TAG, "addItem() called with: itemName = " + itemName + ", quantity = " + quantity + ", price = " + price);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.COLUMN_ITEM_NAME, itemName);
        values.put(InventoryDatabase.COLUMN_QUANTITY, quantity);
        values.put(InventoryDatabase.COLUMN_PRICE, price);
        long newRowId = db.insert(InventoryDatabase.TABLE_NAME, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
            retrieveItems();
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }

    private void retrieveItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                InventoryDatabase.COLUMN_ID,
                InventoryDatabase.COLUMN_ITEM_NAME,
                InventoryDatabase.COLUMN_QUANTITY,
                InventoryDatabase.COLUMN_PRICE
        };
        Cursor cursor = db.query(
                InventoryDatabase.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long itemId = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ITEM_NAME));
            int itemQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_QUANTITY));
            double itemPrice = cursor.getDouble(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_PRICE));
            String itemInfo = "ID: " + itemId + ", Name: " + itemName + ", Quantity: " + itemQuantity + ", Price: " + itemPrice;
            Toast.makeText(this, itemInfo, Toast.LENGTH_LONG).show();
        }
        cursor.close();
    }

    private void searchItems(String query) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                InventoryDatabase.COLUMN_ID,
                InventoryDatabase.COLUMN_ITEM_NAME,
                InventoryDatabase.COLUMN_QUANTITY,
                InventoryDatabase.COLUMN_PRICE
        };
        String selection = InventoryDatabase.COLUMN_ITEM_NAME + " LIKE ?";
        String[] selectionArgs = { "%" + query + "%" };
        Cursor cursor = db.query(
                InventoryDatabase.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long itemId = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_ITEM_NAME));
            int itemQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_QUANTITY));
            double itemPrice = cursor.getDouble(cursor.getColumnIndexOrThrow(InventoryDatabase.COLUMN_PRICE));
            String itemInfo = "ID: " + itemId + ", Name: " + itemName + ", Quantity: " + itemQuantity + ", Price: " + itemPrice;
            Toast.makeText(this, itemInfo, Toast.LENGTH_LONG).show();
        }
        cursor.close();
    }
}
